package com.ctg.ag.sdk.biz.aep_product_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class UpdateProductRequest extends BaseApiRequest {

    public UpdateProductRequest(){
        super(RequestFormat.type("PUT", "application/json; charset=UTF-8"), "20191018204806"
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new UpdateProductResponse();
    }
    
}