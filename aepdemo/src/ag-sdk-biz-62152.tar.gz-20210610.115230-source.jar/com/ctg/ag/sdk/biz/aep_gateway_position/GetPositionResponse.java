package com.ctg.ag.sdk.biz.aep_gateway_position;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetPositionResponse extends BaseApiResponse {
}