package com.ctg.ag.sdk.biz.aep_device_group_management;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class UpdateDeviceGroupRelationResponse extends BaseApiResponse {
}