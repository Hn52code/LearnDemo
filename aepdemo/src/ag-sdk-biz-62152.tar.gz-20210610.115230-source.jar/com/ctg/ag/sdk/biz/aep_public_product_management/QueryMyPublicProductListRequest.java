package com.ctg.ag.sdk.biz.aep_public_product_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryMyPublicProductListRequest extends BaseApiRequest {

    public QueryMyPublicProductListRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20200829005359"
        , new Meta("searchValue", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        , new Meta("productIds", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryMyPublicProductListResponse();
    }
    
    public String getParamSearchValue(){
    	return this.getParam("searchValue");
    }

    public QueryMyPublicProductListRequest setParamSearchValue(Object value){
    	this.setParam("searchValue", value);
    	return this;
    }
    
    public List<String> getParamsSearchValue(){
    	return this.getParams("searchValue");
    }

    public QueryMyPublicProductListRequest addParamSearchValue(Object value){
    	this.addParam("searchValue", value);
    	return this;
    }
    
    public QueryMyPublicProductListRequest addParamsSearchValue(Iterable<?> values){
    	this.addParams("searchValue", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public QueryMyPublicProductListRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public QueryMyPublicProductListRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public QueryMyPublicProductListRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public QueryMyPublicProductListRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public QueryMyPublicProductListRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public QueryMyPublicProductListRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
    public String getParamProductIds(){
    	return this.getParam("productIds");
    }

    public QueryMyPublicProductListRequest setParamProductIds(Object value){
    	this.setParam("productIds", value);
    	return this;
    }
    
    public List<String> getParamsProductIds(){
    	return this.getParams("productIds");
    }

    public QueryMyPublicProductListRequest addParamProductIds(Object value){
    	this.addParam("productIds", value);
    	return this;
    }
    
    public QueryMyPublicProductListRequest addParamsProductIds(Iterable<?> values){
    	this.addParams("productIds", values);
    	return this;
    }
    
}