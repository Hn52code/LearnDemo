package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_public_product_management.QueryPublicByPublicProductIdRequest;
import com.ctg.ag.sdk.biz.aep_public_product_management.QueryPublicByPublicProductIdResponse;
import com.ctg.ag.sdk.biz.aep_public_product_management.QueryPublicByProductIdRequest;
import com.ctg.ag.sdk.biz.aep_public_product_management.QueryPublicByProductIdResponse;
import com.ctg.ag.sdk.biz.aep_public_product_management.InstantiateProductRequest;
import com.ctg.ag.sdk.biz.aep_public_product_management.InstantiateProductResponse;
import com.ctg.ag.sdk.biz.aep_public_product_management.QueryAllPublicProductListRequest;
import com.ctg.ag.sdk.biz.aep_public_product_management.QueryAllPublicProductListResponse;
import com.ctg.ag.sdk.biz.aep_public_product_management.QueryMyPublicProductListRequest;
import com.ctg.ag.sdk.biz.aep_public_product_management.QueryMyPublicProductListResponse;

public final class AepPublicProductManagementClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepPublicProductManagementClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepPublicProductManagementClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_public_product_management");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_public_product_management");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_public_product_management");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_public_product_management");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepPublicProductManagementClient build(BuilderParams params) {
				return new AepPublicProductManagementClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepPublicProductManagementClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public QueryPublicByPublicProductIdResponse QueryPublicByPublicProductId(QueryPublicByPublicProductIdRequest request) throws Exception {
		String apiPath = "/publicProducts";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryPublicByPublicProductIdResponse> QueryPublicByPublicProductId(QueryPublicByPublicProductIdRequest request, ApiCallBack<QueryPublicByPublicProductIdRequest, QueryPublicByPublicProductIdResponse> callback) {
		String apiPath = "/publicProducts";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryPublicByProductIdResponse QueryPublicByProductId(QueryPublicByProductIdRequest request) throws Exception {
		String apiPath = "/publicProductList";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryPublicByProductIdResponse> QueryPublicByProductId(QueryPublicByProductIdRequest request, ApiCallBack<QueryPublicByProductIdRequest, QueryPublicByProductIdResponse> callback) {
		String apiPath = "/publicProductList";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public InstantiateProductResponse InstantiateProduct(InstantiateProductRequest request) throws Exception {
		String apiPath = "/instantiateProduct";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<InstantiateProductResponse> InstantiateProduct(InstantiateProductRequest request, ApiCallBack<InstantiateProductRequest, InstantiateProductResponse> callback) {
		String apiPath = "/instantiateProduct";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryAllPublicProductListResponse QueryAllPublicProductList(QueryAllPublicProductListRequest request) throws Exception {
		String apiPath = "/allPublicProductList";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryAllPublicProductListResponse> QueryAllPublicProductList(QueryAllPublicProductListRequest request, ApiCallBack<QueryAllPublicProductListRequest, QueryAllPublicProductListResponse> callback) {
		String apiPath = "/allPublicProductList";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryMyPublicProductListResponse QueryMyPublicProductList(QueryMyPublicProductListRequest request) throws Exception {
		String apiPath = "/myPublicProductList";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryMyPublicProductListResponse> QueryMyPublicProductList(QueryMyPublicProductListRequest request, ApiCallBack<QueryMyPublicProductListRequest, QueryMyPublicProductListResponse> callback) {
		String apiPath = "/myPublicProductList";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}