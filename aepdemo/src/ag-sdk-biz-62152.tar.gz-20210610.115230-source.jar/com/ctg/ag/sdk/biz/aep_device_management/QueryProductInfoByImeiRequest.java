package com.ctg.ag.sdk.biz.aep_device_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryProductInfoByImeiRequest extends BaseApiRequest {

    public QueryProductInfoByImeiRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20191213161859"
        , new Meta("imei", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryProductInfoByImeiResponse();
    }
    
    public String getParamImei(){
    	return this.getParam("imei");
    }

    public QueryProductInfoByImeiRequest setParamImei(Object value){
    	this.setParam("imei", value);
    	return this;
    }
    
    public List<String> getParamsImei(){
    	return this.getParams("imei");
    }

    public QueryProductInfoByImeiRequest addParamImei(Object value){
    	this.addParam("imei", value);
    	return this;
    }
    
    public QueryProductInfoByImeiRequest addParamsImei(Iterable<?> values){
    	this.addParams("imei", values);
    	return this;
    }
    
}