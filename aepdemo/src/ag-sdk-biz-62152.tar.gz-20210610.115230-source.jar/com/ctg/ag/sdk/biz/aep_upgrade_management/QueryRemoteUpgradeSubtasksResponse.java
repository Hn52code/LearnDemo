package com.ctg.ag.sdk.biz.aep_upgrade_management;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryRemoteUpgradeSubtasksResponse extends BaseApiResponse {
}