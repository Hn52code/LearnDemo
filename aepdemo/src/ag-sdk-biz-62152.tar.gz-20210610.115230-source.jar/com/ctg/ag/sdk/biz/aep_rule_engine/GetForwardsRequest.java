package com.ctg.ag.sdk.biz.aep_rule_engine;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetForwardsRequest extends BaseApiRequest {

    public GetForwardsRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20210327062531"
        , new Meta("ruleId", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new GetForwardsResponse();
    }
    
    public String getParamRuleId(){
    	return this.getParam("ruleId");
    }

    public GetForwardsRequest setParamRuleId(Object value){
    	this.setParam("ruleId", value);
    	return this;
    }
    
    public List<String> getParamsRuleId(){
    	return this.getParams("ruleId");
    }

    public GetForwardsRequest addParamRuleId(Object value){
    	this.addParam("ruleId", value);
    	return this;
    }
    
    public GetForwardsRequest addParamsRuleId(Iterable<?> values){
    	this.addParams("ruleId", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public GetForwardsRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public GetForwardsRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public GetForwardsRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public GetForwardsRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public GetForwardsRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public GetForwardsRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public GetForwardsRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public GetForwardsRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public GetForwardsRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
}