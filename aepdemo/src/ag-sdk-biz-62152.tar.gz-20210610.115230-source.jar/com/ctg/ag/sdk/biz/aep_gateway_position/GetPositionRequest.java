package com.ctg.ag.sdk.biz.aep_gateway_position;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetPositionRequest extends BaseApiRequest {

    public GetPositionRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20190301085737"
        , new Meta("cardId", ParamPosition.QUERY)
        , new Meta("posReqType", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new GetPositionResponse();
    }
    
    public String getParamCardId(){
    	return this.getParam("cardId");
    }

    public GetPositionRequest setParamCardId(Object value){
    	this.setParam("cardId", value);
    	return this;
    }
    
    public List<String> getParamsCardId(){
    	return this.getParams("cardId");
    }

    public GetPositionRequest addParamCardId(Object value){
    	this.addParam("cardId", value);
    	return this;
    }
    
    public GetPositionRequest addParamsCardId(Iterable<?> values){
    	this.addParams("cardId", values);
    	return this;
    }
    
    public String getParamPosReqType(){
    	return this.getParam("posReqType");
    }

    public GetPositionRequest setParamPosReqType(Object value){
    	this.setParam("posReqType", value);
    	return this;
    }
    
    public List<String> getParamsPosReqType(){
    	return this.getParams("posReqType");
    }

    public GetPositionRequest addParamPosReqType(Object value){
    	this.addParam("posReqType", value);
    	return this;
    }
    
    public GetPositionRequest addParamsPosReqType(Iterable<?> values){
    	this.addParams("posReqType", values);
    	return this;
    }
    
}