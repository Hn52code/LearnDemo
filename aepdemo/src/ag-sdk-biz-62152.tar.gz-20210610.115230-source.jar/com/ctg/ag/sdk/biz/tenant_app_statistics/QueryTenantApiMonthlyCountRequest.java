package com.ctg.ag.sdk.biz.tenant_app_statistics;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryTenantApiMonthlyCountRequest extends BaseApiRequest {

    public QueryTenantApiMonthlyCountRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20201225122609"
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryTenantApiMonthlyCountResponse();
    }
    
}