package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_modbus_device_management.UpdateDeviceRequest;
import com.ctg.ag.sdk.biz.aep_modbus_device_management.UpdateDeviceResponse;
import com.ctg.ag.sdk.biz.aep_modbus_device_management.CreateDeviceRequest;
import com.ctg.ag.sdk.biz.aep_modbus_device_management.CreateDeviceResponse;
import com.ctg.ag.sdk.biz.aep_modbus_device_management.QueryDeviceRequest;
import com.ctg.ag.sdk.biz.aep_modbus_device_management.QueryDeviceResponse;
import com.ctg.ag.sdk.biz.aep_modbus_device_management.QueryDeviceListRequest;
import com.ctg.ag.sdk.biz.aep_modbus_device_management.QueryDeviceListResponse;
import com.ctg.ag.sdk.biz.aep_modbus_device_management.DeleteDeviceRequest;
import com.ctg.ag.sdk.biz.aep_modbus_device_management.DeleteDeviceResponse;

public final class AepModbusDeviceManagementClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepModbusDeviceManagementClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepModbusDeviceManagementClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_modbus_device_management");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_modbus_device_management");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_modbus_device_management");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_modbus_device_management");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepModbusDeviceManagementClient build(BuilderParams params) {
				return new AepModbusDeviceManagementClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepModbusDeviceManagementClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public UpdateDeviceResponse UpdateDevice(UpdateDeviceRequest request) throws Exception {
		String apiPath = "/modbus/device";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<UpdateDeviceResponse> UpdateDevice(UpdateDeviceRequest request, ApiCallBack<UpdateDeviceRequest, UpdateDeviceResponse> callback) {
		String apiPath = "/modbus/device";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public CreateDeviceResponse CreateDevice(CreateDeviceRequest request) throws Exception {
		String apiPath = "/modbus/device";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<CreateDeviceResponse> CreateDevice(CreateDeviceRequest request, ApiCallBack<CreateDeviceRequest, CreateDeviceResponse> callback) {
		String apiPath = "/modbus/device";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryDeviceResponse QueryDevice(QueryDeviceRequest request) throws Exception {
		String apiPath = "/modbus/device";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryDeviceResponse> QueryDevice(QueryDeviceRequest request, ApiCallBack<QueryDeviceRequest, QueryDeviceResponse> callback) {
		String apiPath = "/modbus/device";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryDeviceListResponse QueryDeviceList(QueryDeviceListRequest request) throws Exception {
		String apiPath = "/modbus/devices";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryDeviceListResponse> QueryDeviceList(QueryDeviceListRequest request, ApiCallBack<QueryDeviceListRequest, QueryDeviceListResponse> callback) {
		String apiPath = "/modbus/devices";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public DeleteDeviceResponse DeleteDevice(DeleteDeviceRequest request) throws Exception {
		String apiPath = "/modbus/device";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<DeleteDeviceResponse> DeleteDevice(DeleteDeviceRequest request, ApiCallBack<DeleteDeviceRequest, DeleteDeviceResponse> callback) {
		String apiPath = "/modbus/device";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}