package com.ctg.ag.sdk.biz.aep_mq_sub;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class OpenMqServiceRequest extends BaseApiRequest {

    public OpenMqServiceRequest(){
        super(RequestFormat.type("POST", "application/x-www-form-urlencoded; charset=UTF-8"), "20201217094438"
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new OpenMqServiceResponse();
    }
    
}