package com.ctg.ag.sdk.biz.aep_software_management;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class UpdateSoftwareResponse extends BaseApiResponse {
}