package com.ctg.ag.sdk.biz.aep_device_command_lwm_profile;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class CreateCommandLwm2mProfileResponse extends BaseApiResponse {
}