package com.ctg.ag.sdk.biz.aep_rule_engine;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class SaasQueryRuleRequest extends BaseApiRequest {

    public SaasQueryRuleRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20200111000633"
        , new Meta("ruleId", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new SaasQueryRuleResponse();
    }
    
    public String getParamRuleId(){
    	return this.getParam("ruleId");
    }

    public SaasQueryRuleRequest setParamRuleId(Object value){
    	this.setParam("ruleId", value);
    	return this;
    }
    
    public List<String> getParamsRuleId(){
    	return this.getParams("ruleId");
    }

    public SaasQueryRuleRequest addParamRuleId(Object value){
    	this.addParam("ruleId", value);
    	return this;
    }
    
    public SaasQueryRuleRequest addParamsRuleId(Iterable<?> values){
    	this.addParams("ruleId", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public SaasQueryRuleRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public SaasQueryRuleRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public SaasQueryRuleRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public SaasQueryRuleRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public SaasQueryRuleRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public SaasQueryRuleRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public SaasQueryRuleRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public SaasQueryRuleRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public SaasQueryRuleRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
}