package com.ctg.ag.sdk.biz.aep_upgrade_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryRemoteUpgradeSubtasksRequest extends BaseApiRequest {

    public QueryRemoteUpgradeSubtasksRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20190615001406"
        , new Meta("id", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("taskStatus", ParamPosition.QUERY)
        , new Meta("searchValue", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryRemoteUpgradeSubtasksResponse();
    }
    
    public String getParamId(){
    	return this.getParam("id");
    }

    public QueryRemoteUpgradeSubtasksRequest setParamId(Object value){
    	this.setParam("id", value);
    	return this;
    }
    
    public List<String> getParamsId(){
    	return this.getParams("id");
    }

    public QueryRemoteUpgradeSubtasksRequest addParamId(Object value){
    	this.addParam("id", value);
    	return this;
    }
    
    public QueryRemoteUpgradeSubtasksRequest addParamsId(Iterable<?> values){
    	this.addParams("id", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public QueryRemoteUpgradeSubtasksRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public QueryRemoteUpgradeSubtasksRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public QueryRemoteUpgradeSubtasksRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamTaskStatus(){
    	return this.getParam("taskStatus");
    }

    public QueryRemoteUpgradeSubtasksRequest setParamTaskStatus(Object value){
    	this.setParam("taskStatus", value);
    	return this;
    }
    
    public List<String> getParamsTaskStatus(){
    	return this.getParams("taskStatus");
    }

    public QueryRemoteUpgradeSubtasksRequest addParamTaskStatus(Object value){
    	this.addParam("taskStatus", value);
    	return this;
    }
    
    public QueryRemoteUpgradeSubtasksRequest addParamsTaskStatus(Iterable<?> values){
    	this.addParams("taskStatus", values);
    	return this;
    }
    
    public String getParamSearchValue(){
    	return this.getParam("searchValue");
    }

    public QueryRemoteUpgradeSubtasksRequest setParamSearchValue(Object value){
    	this.setParam("searchValue", value);
    	return this;
    }
    
    public List<String> getParamsSearchValue(){
    	return this.getParams("searchValue");
    }

    public QueryRemoteUpgradeSubtasksRequest addParamSearchValue(Object value){
    	this.addParam("searchValue", value);
    	return this;
    }
    
    public QueryRemoteUpgradeSubtasksRequest addParamsSearchValue(Iterable<?> values){
    	this.addParams("searchValue", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public QueryRemoteUpgradeSubtasksRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public QueryRemoteUpgradeSubtasksRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public QueryRemoteUpgradeSubtasksRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public QueryRemoteUpgradeSubtasksRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public QueryRemoteUpgradeSubtasksRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public QueryRemoteUpgradeSubtasksRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public QueryRemoteUpgradeSubtasksRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public QueryRemoteUpgradeSubtasksRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public QueryRemoteUpgradeSubtasksRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}