package com.ctg.ag.sdk.biz.aep_edge_gateway;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryEdgeInstanceDeviceRequest extends BaseApiRequest {

    public QueryEdgeInstanceDeviceRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20201226000022"
        , new Meta("gatewayDeviceId", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryEdgeInstanceDeviceResponse();
    }
    
    public String getParamGatewayDeviceId(){
    	return this.getParam("gatewayDeviceId");
    }

    public QueryEdgeInstanceDeviceRequest setParamGatewayDeviceId(Object value){
    	this.setParam("gatewayDeviceId", value);
    	return this;
    }
    
    public List<String> getParamsGatewayDeviceId(){
    	return this.getParams("gatewayDeviceId");
    }

    public QueryEdgeInstanceDeviceRequest addParamGatewayDeviceId(Object value){
    	this.addParam("gatewayDeviceId", value);
    	return this;
    }
    
    public QueryEdgeInstanceDeviceRequest addParamsGatewayDeviceId(Iterable<?> values){
    	this.addParams("gatewayDeviceId", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public QueryEdgeInstanceDeviceRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public QueryEdgeInstanceDeviceRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public QueryEdgeInstanceDeviceRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public QueryEdgeInstanceDeviceRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public QueryEdgeInstanceDeviceRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public QueryEdgeInstanceDeviceRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
}