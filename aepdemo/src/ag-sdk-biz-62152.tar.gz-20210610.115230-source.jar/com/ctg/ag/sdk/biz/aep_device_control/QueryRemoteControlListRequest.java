package com.ctg.ag.sdk.biz.aep_device_control;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryRemoteControlListRequest extends BaseApiRequest {

    public QueryRemoteControlListRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20190507012630"
        , new Meta("MasterKey", ParamPosition.HEAD)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("searchValue", ParamPosition.QUERY)
        , new Meta("type", ParamPosition.QUERY)
        , new Meta("status", ParamPosition.QUERY)
        , new Meta("startTime", ParamPosition.QUERY)
        , new Meta("endTime", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryRemoteControlListResponse();
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public QueryRemoteControlListRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public QueryRemoteControlListRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public QueryRemoteControlListRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public QueryRemoteControlListRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public QueryRemoteControlListRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public QueryRemoteControlListRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamSearchValue(){
    	return this.getParam("searchValue");
    }

    public QueryRemoteControlListRequest setParamSearchValue(Object value){
    	this.setParam("searchValue", value);
    	return this;
    }
    
    public List<String> getParamsSearchValue(){
    	return this.getParams("searchValue");
    }

    public QueryRemoteControlListRequest addParamSearchValue(Object value){
    	this.addParam("searchValue", value);
    	return this;
    }
    
    public QueryRemoteControlListRequest addParamsSearchValue(Iterable<?> values){
    	this.addParams("searchValue", values);
    	return this;
    }
    
    public String getParamType(){
    	return this.getParam("type");
    }

    public QueryRemoteControlListRequest setParamType(Object value){
    	this.setParam("type", value);
    	return this;
    }
    
    public List<String> getParamsType(){
    	return this.getParams("type");
    }

    public QueryRemoteControlListRequest addParamType(Object value){
    	this.addParam("type", value);
    	return this;
    }
    
    public QueryRemoteControlListRequest addParamsType(Iterable<?> values){
    	this.addParams("type", values);
    	return this;
    }
    
    public String getParamStatus(){
    	return this.getParam("status");
    }

    public QueryRemoteControlListRequest setParamStatus(Object value){
    	this.setParam("status", value);
    	return this;
    }
    
    public List<String> getParamsStatus(){
    	return this.getParams("status");
    }

    public QueryRemoteControlListRequest addParamStatus(Object value){
    	this.addParam("status", value);
    	return this;
    }
    
    public QueryRemoteControlListRequest addParamsStatus(Iterable<?> values){
    	this.addParams("status", values);
    	return this;
    }
    
    public String getParamStartTime(){
    	return this.getParam("startTime");
    }

    public QueryRemoteControlListRequest setParamStartTime(Object value){
    	this.setParam("startTime", value);
    	return this;
    }
    
    public List<String> getParamsStartTime(){
    	return this.getParams("startTime");
    }

    public QueryRemoteControlListRequest addParamStartTime(Object value){
    	this.addParam("startTime", value);
    	return this;
    }
    
    public QueryRemoteControlListRequest addParamsStartTime(Iterable<?> values){
    	this.addParams("startTime", values);
    	return this;
    }
    
    public String getParamEndTime(){
    	return this.getParam("endTime");
    }

    public QueryRemoteControlListRequest setParamEndTime(Object value){
    	this.setParam("endTime", value);
    	return this;
    }
    
    public List<String> getParamsEndTime(){
    	return this.getParams("endTime");
    }

    public QueryRemoteControlListRequest addParamEndTime(Object value){
    	this.addParam("endTime", value);
    	return this;
    }
    
    public QueryRemoteControlListRequest addParamsEndTime(Iterable<?> values){
    	this.addParams("endTime", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public QueryRemoteControlListRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public QueryRemoteControlListRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public QueryRemoteControlListRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public QueryRemoteControlListRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public QueryRemoteControlListRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public QueryRemoteControlListRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
}