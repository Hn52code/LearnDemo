package com.ctg.ag.sdk.biz.aep_upgrade_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryRemoteUpgradeTaskRequest extends BaseApiRequest {

    public QueryRemoteUpgradeTaskRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20190615001509"
        , new Meta("id", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryRemoteUpgradeTaskResponse();
    }
    
    public String getParamId(){
    	return this.getParam("id");
    }

    public QueryRemoteUpgradeTaskRequest setParamId(Object value){
    	this.setParam("id", value);
    	return this;
    }
    
    public List<String> getParamsId(){
    	return this.getParams("id");
    }

    public QueryRemoteUpgradeTaskRequest addParamId(Object value){
    	this.addParam("id", value);
    	return this;
    }
    
    public QueryRemoteUpgradeTaskRequest addParamsId(Iterable<?> values){
    	this.addParams("id", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public QueryRemoteUpgradeTaskRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public QueryRemoteUpgradeTaskRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public QueryRemoteUpgradeTaskRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public QueryRemoteUpgradeTaskRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public QueryRemoteUpgradeTaskRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public QueryRemoteUpgradeTaskRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}