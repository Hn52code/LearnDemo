package com.ctg.ag.sdk.biz.aep_standard_management;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryStandardModelResponse extends BaseApiResponse {
}