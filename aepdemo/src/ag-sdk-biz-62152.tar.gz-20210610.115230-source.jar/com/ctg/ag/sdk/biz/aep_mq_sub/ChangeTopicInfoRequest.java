package com.ctg.ag.sdk.biz.aep_mq_sub;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class ChangeTopicInfoRequest extends BaseApiRequest {

    public ChangeTopicInfoRequest(){
        super(RequestFormat.type("PUT", "application/json; charset=UTF-8"), "20201218153044"
        , new Meta("topicId", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new ChangeTopicInfoResponse();
    }
    
    public String getParamTopicId(){
    	return this.getParam("topicId");
    }

    public ChangeTopicInfoRequest setParamTopicId(Object value){
    	this.setParam("topicId", value);
    	return this;
    }
    
    public List<String> getParamsTopicId(){
    	return this.getParams("topicId");
    }

    public ChangeTopicInfoRequest addParamTopicId(Object value){
    	this.addParam("topicId", value);
    	return this;
    }
    
    public ChangeTopicInfoRequest addParamsTopicId(Iterable<?> values){
    	this.addParams("topicId", values);
    	return this;
    }
    
}