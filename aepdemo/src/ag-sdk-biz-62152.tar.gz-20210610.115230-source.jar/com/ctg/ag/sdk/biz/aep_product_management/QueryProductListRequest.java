package com.ctg.ag.sdk.biz.aep_product_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryProductListRequest extends BaseApiRequest {

    public QueryProductListRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20190507004824"
        , new Meta("searchValue", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryProductListResponse();
    }
    
    public String getParamSearchValue(){
    	return this.getParam("searchValue");
    }

    public QueryProductListRequest setParamSearchValue(Object value){
    	this.setParam("searchValue", value);
    	return this;
    }
    
    public List<String> getParamsSearchValue(){
    	return this.getParams("searchValue");
    }

    public QueryProductListRequest addParamSearchValue(Object value){
    	this.addParam("searchValue", value);
    	return this;
    }
    
    public QueryProductListRequest addParamsSearchValue(Iterable<?> values){
    	this.addParams("searchValue", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public QueryProductListRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public QueryProductListRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public QueryProductListRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public QueryProductListRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public QueryProductListRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public QueryProductListRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
}