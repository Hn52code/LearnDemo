package com.ctg.ag.sdk.biz.aep_subscribe_north;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class GetSubscriptionRequest extends BaseApiRequest {

    public GetSubscriptionRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20181031202033"
        , new Meta("subId", ParamPosition.QUERY)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new GetSubscriptionResponse();
    }
    
    public String getParamSubId(){
    	return this.getParam("subId");
    }

    public GetSubscriptionRequest setParamSubId(Object value){
    	this.setParam("subId", value);
    	return this;
    }
    
    public List<String> getParamsSubId(){
    	return this.getParams("subId");
    }

    public GetSubscriptionRequest addParamSubId(Object value){
    	this.addParam("subId", value);
    	return this;
    }
    
    public GetSubscriptionRequest addParamsSubId(Iterable<?> values){
    	this.addParams("subId", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public GetSubscriptionRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public GetSubscriptionRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public GetSubscriptionRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public GetSubscriptionRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public GetSubscriptionRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public GetSubscriptionRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}