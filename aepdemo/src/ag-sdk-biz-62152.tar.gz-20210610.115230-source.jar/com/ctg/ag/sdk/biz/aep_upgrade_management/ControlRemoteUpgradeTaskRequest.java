package com.ctg.ag.sdk.biz.aep_upgrade_management;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class ControlRemoteUpgradeTaskRequest extends BaseApiRequest {

    public ControlRemoteUpgradeTaskRequest(){
        super(RequestFormat.type("PUT", "application/json; charset=UTF-8"), "20190615001456"
        , new Meta("id", ParamPosition.QUERY)
        , new Meta("MasterKey", ParamPosition.HEAD)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new ControlRemoteUpgradeTaskResponse();
    }
    
    public String getParamId(){
    	return this.getParam("id");
    }

    public ControlRemoteUpgradeTaskRequest setParamId(Object value){
    	this.setParam("id", value);
    	return this;
    }
    
    public List<String> getParamsId(){
    	return this.getParams("id");
    }

    public ControlRemoteUpgradeTaskRequest addParamId(Object value){
    	this.addParam("id", value);
    	return this;
    }
    
    public ControlRemoteUpgradeTaskRequest addParamsId(Iterable<?> values){
    	this.addParams("id", values);
    	return this;
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public ControlRemoteUpgradeTaskRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public ControlRemoteUpgradeTaskRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public ControlRemoteUpgradeTaskRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
}