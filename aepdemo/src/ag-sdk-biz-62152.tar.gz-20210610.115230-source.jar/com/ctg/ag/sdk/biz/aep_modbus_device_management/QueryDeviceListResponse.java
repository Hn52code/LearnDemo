package com.ctg.ag.sdk.biz.aep_modbus_device_management;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryDeviceListResponse extends BaseApiResponse {
}