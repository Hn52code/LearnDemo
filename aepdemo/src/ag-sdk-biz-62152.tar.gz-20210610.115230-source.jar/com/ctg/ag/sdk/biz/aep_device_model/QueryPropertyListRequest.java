package com.ctg.ag.sdk.biz.aep_device_model;

import java.util.List;
import com.ctg.ag.sdk.core.constant.*;
import com.ctg.ag.sdk.core.http.RequestFormat;
import com.ctg.ag.sdk.core.model.BaseApiRequest;
import com.ctg.ag.sdk.core.model.BaseApiResponse;

public class QueryPropertyListRequest extends BaseApiRequest {

    public QueryPropertyListRequest(){
        super(RequestFormat.type("GET", "application/x-www-form-urlencoded; charset=UTF-8"), "20190712223330"
        , new Meta("MasterKey", ParamPosition.HEAD)
        , new Meta("productId", ParamPosition.QUERY)
        , new Meta("searchValue", ParamPosition.QUERY)
        , new Meta("pageNow", ParamPosition.QUERY)
        , new Meta("pageSize", ParamPosition.QUERY)
        );
    }

    @Override
    public BaseApiResponse newResponse() {
        return new QueryPropertyListResponse();
    }
    
    public String getParamMasterKey(){
    	return this.getParam("MasterKey");
    }

    public QueryPropertyListRequest setParamMasterKey(Object value){
    	this.setParam("MasterKey", value);
    	return this;
    }
    
    public List<String> getParamsMasterKey(){
    	return this.getParams("MasterKey");
    }

    public QueryPropertyListRequest addParamMasterKey(Object value){
    	this.addParam("MasterKey", value);
    	return this;
    }
    
    public QueryPropertyListRequest addParamsMasterKey(Iterable<?> values){
    	this.addParams("MasterKey", values);
    	return this;
    }
    
    public String getParamProductId(){
    	return this.getParam("productId");
    }

    public QueryPropertyListRequest setParamProductId(Object value){
    	this.setParam("productId", value);
    	return this;
    }
    
    public List<String> getParamsProductId(){
    	return this.getParams("productId");
    }

    public QueryPropertyListRequest addParamProductId(Object value){
    	this.addParam("productId", value);
    	return this;
    }
    
    public QueryPropertyListRequest addParamsProductId(Iterable<?> values){
    	this.addParams("productId", values);
    	return this;
    }
    
    public String getParamSearchValue(){
    	return this.getParam("searchValue");
    }

    public QueryPropertyListRequest setParamSearchValue(Object value){
    	this.setParam("searchValue", value);
    	return this;
    }
    
    public List<String> getParamsSearchValue(){
    	return this.getParams("searchValue");
    }

    public QueryPropertyListRequest addParamSearchValue(Object value){
    	this.addParam("searchValue", value);
    	return this;
    }
    
    public QueryPropertyListRequest addParamsSearchValue(Iterable<?> values){
    	this.addParams("searchValue", values);
    	return this;
    }
    
    public String getParamPageNow(){
    	return this.getParam("pageNow");
    }

    public QueryPropertyListRequest setParamPageNow(Object value){
    	this.setParam("pageNow", value);
    	return this;
    }
    
    public List<String> getParamsPageNow(){
    	return this.getParams("pageNow");
    }

    public QueryPropertyListRequest addParamPageNow(Object value){
    	this.addParam("pageNow", value);
    	return this;
    }
    
    public QueryPropertyListRequest addParamsPageNow(Iterable<?> values){
    	this.addParams("pageNow", values);
    	return this;
    }
    
    public String getParamPageSize(){
    	return this.getParam("pageSize");
    }

    public QueryPropertyListRequest setParamPageSize(Object value){
    	this.setParam("pageSize", value);
    	return this;
    }
    
    public List<String> getParamsPageSize(){
    	return this.getParams("pageSize");
    }

    public QueryPropertyListRequest addParamPageSize(Object value){
    	this.addParam("pageSize", value);
    	return this;
    }
    
    public QueryPropertyListRequest addParamsPageSize(Iterable<?> values){
    	this.addParams("pageSize", values);
    	return this;
    }
    
}