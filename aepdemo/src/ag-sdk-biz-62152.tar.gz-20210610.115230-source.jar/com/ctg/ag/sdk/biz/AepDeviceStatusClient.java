package com.ctg.ag.sdk.biz;

import java.util.List;
import java.util.ArrayList;
import java.util.concurrent.Future;

import com.ctg.ag.sdk.core.BaseApiClient;
import com.ctg.ag.sdk.core.BaseApiClientBuilder;
import com.ctg.ag.sdk.core.model.ApiCallBack;
import com.ctg.ag.sdk.core.model.BuilderParams;

import com.ctg.ag.sdk.biz.aep_device_status.QueryDeviceStatusRequest;
import com.ctg.ag.sdk.biz.aep_device_status.QueryDeviceStatusResponse;
import com.ctg.ag.sdk.biz.aep_device_status.QueryDeviceStatusListRequest;
import com.ctg.ag.sdk.biz.aep_device_status.QueryDeviceStatusListResponse;
import com.ctg.ag.sdk.biz.aep_device_status.GetDeviceStatusHisInTotalRequest;
import com.ctg.ag.sdk.biz.aep_device_status.GetDeviceStatusHisInTotalResponse;
import com.ctg.ag.sdk.biz.aep_device_status.GetDeviceStatusHisInPageRequest;
import com.ctg.ag.sdk.biz.aep_device_status.GetDeviceStatusHisInPageResponse;

public final class AepDeviceStatusClient extends BaseApiClient {

	public static BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepDeviceStatusClient> newClient() {
		return new BaseApiClientBuilder<BaseApiClientBuilder<?, ?>, AepDeviceStatusClient>() {

			private String[] serverHosts;
			private String[] serverSslHosts;
			private String[] httpHosts;
			private String[] sslHosts;
			private String[] sandboxHttpHosts;
			private String[] sandboxSslHosts;

			{
				List<String> serverHosts = new ArrayList<String>();
				serverHosts.add("ag-api.ctwing.cn");
                this.serverHosts = serverHosts.toArray(new String[0]);

				List<String> serverSslHosts = new ArrayList<String>();
				serverSslHosts.add("ag-api.ctwing.cn");
                this.serverSslHosts = serverSslHosts.toArray(new String[0]);
                
				List<String> httpHosts = new ArrayList<String>();
				httpHosts.add("ag-api.ctwing.cn/aep_device_status");
                this.httpHosts = httpHosts.toArray(new String[0]);

				List<String> sslHosts = new ArrayList<String>();
				sslHosts.add("ag-api.ctwing.cn/aep_device_status");
				this.sslHosts = sslHosts.toArray(new String[0]);

				List<String> sandboxHttpHosts = new ArrayList<String>();
				sandboxHttpHosts.add("ag-api.ctwing.cn/aep_device_status");
                this.sandboxHttpHosts = sandboxHttpHosts.toArray(new String[0]);

				List<String> sandboxSslHosts = new ArrayList<String>();
				sandboxSslHosts.add("ag-api.ctwing.cn/aep_device_status");
                this.sandboxSslHosts = sandboxSslHosts.toArray(new String[0]);
			}

			@Override
			protected AepDeviceStatusClient build(BuilderParams params) {
				return new AepDeviceStatusClient(params);
			}

			@Override
			protected String serverHost() {
			   return nextHost(serverHosts);
			}
			
			@Override
			protected String serverSslHost() {
			   return nextHost(serverSslHosts);
			}

			@Override
			protected String httpHost() {
			    return nextHost(httpHosts);
			}

			@Override
			protected String sslHost() {
			    return nextHost(sslHosts);
			}

			@Override
			protected String sandboxHttpHost() {
			    return nextHost(sandboxHttpHosts);
			}

			@Override
			protected String sandboxSslHost() {
			    return nextHost(sandboxSslHosts);
			}

		};
	}

	private AepDeviceStatusClient(BuilderParams builderParams) {
		super(builderParams);
	}

	public QueryDeviceStatusResponse QueryDeviceStatus(QueryDeviceStatusRequest request) throws Exception {
		String apiPath = "/deviceStatus";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryDeviceStatusResponse> QueryDeviceStatus(QueryDeviceStatusRequest request, ApiCallBack<QueryDeviceStatusRequest, QueryDeviceStatusResponse> callback) {
		String apiPath = "/deviceStatus";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public QueryDeviceStatusListResponse QueryDeviceStatusList(QueryDeviceStatusListRequest request) throws Exception {
		String apiPath = "/deviceStatusList";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<QueryDeviceStatusListResponse> QueryDeviceStatusList(QueryDeviceStatusListRequest request, ApiCallBack<QueryDeviceStatusListRequest, QueryDeviceStatusListResponse> callback) {
		String apiPath = "/deviceStatusList";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetDeviceStatusHisInTotalResponse getDeviceStatusHisInTotal(GetDeviceStatusHisInTotalRequest request) throws Exception {
		String apiPath = "/api/v1/getDeviceStatusHisInTotal";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetDeviceStatusHisInTotalResponse> getDeviceStatusHisInTotal(GetDeviceStatusHisInTotalRequest request, ApiCallBack<GetDeviceStatusHisInTotalRequest, GetDeviceStatusHisInTotalResponse> callback) {
		String apiPath = "/api/v1/getDeviceStatusHisInTotal";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}

	public GetDeviceStatusHisInPageResponse getDeviceStatusHisInPage(GetDeviceStatusHisInPageRequest request) throws Exception {
		String apiPath = "/getDeviceStatusHisInPage";

		request.setPath(apiPath);

		return syncInvoke(request);
	}

	public Future<GetDeviceStatusHisInPageResponse> getDeviceStatusHisInPage(GetDeviceStatusHisInPageRequest request, ApiCallBack<GetDeviceStatusHisInPageRequest, GetDeviceStatusHisInPageResponse> callback) {
		String apiPath = "/getDeviceStatusHisInPage";

		request.setPath(apiPath);

		return asyncInvoke(request, callback);
	}


}